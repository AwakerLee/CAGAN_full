# CAGAN
CLIP-based Adaptive Graph Attention Network for unsupervised cross-modal hashing retrieval.

More details will be updated soon.

### Requirements
Please, install the following packages:

- python == 3.x 
- CLIP
- pytorch
- torchvision
- h5py

### Citation

